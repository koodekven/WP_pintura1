<?php
/**
 * Elementor rsgallery Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */

use Elementor\Controls_Manager;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Utils;


defined( 'ABSPATH' ) || die();

class Rsaddon_Elementor_Pro_Blog_Slider_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve rsgallery widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'rsblog-slider';
    }       

    /**
     * Get widget title.
     *
     * Retrieve rsgallery widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'RS Blog Slider', 'rsaddon' );
    }

    /**
     * Get widget icon.
     *
     * Retrieve rsgallery widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'glyph-icon flaticon-slider-1';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the rsgallery widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'rsaddon_category' ];
    }

    /**
     * Register rsgallery widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {       
        $category_dropdown[0] = 'Select Category';
        $terms  = get_terms( array( 'taxonomy' => "category", 'fields' => 'id=>name' ) );       
        foreach ( $terms as $id => $name ) {
            $category_dropdown[$id] = $name;
        } 
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'rsaddon' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'category',
            [
                'label'   => esc_html__( 'Category', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT2, 
                'default' => 0,         
                'options' => [      
                        
                ]+ $category_dropdown,
                'multiple' => true, 
                'separator' => 'before',        
            ]

        );
        $this->add_control(
            'per_page',
            [
                'label' => esc_html__( 'Blog Show Per Page', 'rsaddon' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( '6', 'rsaddon' ),
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'blog_content_postion_style',
            [
                'label' => esc_html__( 'Content Style', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => esc_html__( 'Default', 'rsaddon' ),
                    'blog_style_2' => esc_html__( 'Blog Style Two', 'rsaddon' ),
                    'blog_style_3' => esc_html__( 'Blog Style Three', 'rsaddon' ),
                    'blog_style_4' => esc_html__( 'Blog Style Four', 'rsaddon' ),
                    'blog_style_5' => esc_html__( 'Blog Style Five', 'rsaddon' ),
                    'transparent' => esc_html__( 'Transparent One', 'rsaddon' ),
                    'transparent_2' => esc_html__( 'Transparent Style Two', 'rsaddon' ),
                ],                
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'blog_cat_postion_style',
            [
                'label' => esc_html__( 'Category Position', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'bottom',
                'options' => [
                    'bottom' => esc_html__( 'Bottom', 'rsaddon' ),
                    'top' => esc_html__( 'Top', 'rsaddon' ),
                ],                
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'meta_postion_style',
            [
                'label' => esc_html__( 'Meta Position', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'top',
                'options' => [
                    'bottom' => esc_html__( 'Bottom', 'rsaddon' ),
                    'top' => esc_html__( 'Top', 'rsaddon' ),
                ],                
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'blog_avatar_show_hide',
            [
                'label' => esc_html__( 'Author Show/Hide', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'no',
                'options' => [
                    'yes' => esc_html__( 'Yes', 'rsaddon' ),
                    'no' => esc_html__( 'No', 'rsaddon' ),
                ],                
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'blog_avatar_icon_show',
            [
                'label' => esc_html__( 'Author Icon', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'no',
                'options' => [
                    'yes' => esc_html__( 'Yes', 'rsaddon' ),
                    'no' => esc_html__( 'No', 'rsaddon' ),
                ],
                'condition' => [
                    'blog_avatar_show_hide' => 'yes',
                    'blog_content_postion_style' => 'blog_style_5',
                ],
            ]
        );
        $this->add_control(
			'avatar_selected_icon',
			[
				'label'     => esc_html__( 'Select Icon', 'rsaddon' ),
				'type'      => Controls_Manager::ICON,
				'options'   => rsaddon_pro_get_icons(),				
				'default'   => 'fa fa-smile-o',
				'condition' => [
					'blog_avatar_show_hide' => 'yes',
					'blog_avatar_icon_show' => 'yes',
                    'blog_content_postion_style' => 'blog_style_5',
				],				
			]
		);


        $this->add_control(
            'blog_cat_show_hide',
            [
                'label' => esc_html__( 'Category Show/Hide', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'no',
                'options' => [
                    'yes' => esc_html__( 'Yes', 'rsaddon' ),
                    'no' => esc_html__( 'No', 'rsaddon' ),
                ],                
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'blog_cat_icon_show',
            [
                'label' => esc_html__( 'Category Icon', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'no',
                'options' => [
                    'yes' => esc_html__( 'Yes', 'rsaddon' ),
                    'no' => esc_html__( 'No', 'rsaddon' ),
                ],
                'condition' => [
                    'blog_cat_show_hide' => 'yes',
                    'blog_content_postion_style' => 'blog_style_5',
                ],
            ]
        );
        $this->add_control(
			'cat_selected_icon',
			[
				'label'     => esc_html__( 'Select Icon', 'rsaddon' ),
				'type'      => Controls_Manager::ICON,
				'options'   => rsaddon_pro_get_icons(),				
				'default'   => 'fa fa-smile-o',
				'condition' => [
					'blog_cat_show_hide' => 'yes',
					'blog_cat_icon_show' => 'yes',
                    'blog_content_postion_style' => 'blog_style_5',
				],				
			]
		);



        $this->add_control(
            'blog_meta_show_hide',
            [
                'label' => esc_html__( 'Date Show/Hide', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'yes',
                'options' => [
                    'yes' => esc_html__( 'Yes', 'rsaddon' ),
                    'no' => esc_html__( 'No', 'rsaddon' ),
                ],                
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'date_style',
            [
                'label' => esc_html__( 'Date Style', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'style1',
                'options' => [
                    'style1' => esc_html__( 'Style 1', 'rsaddon' ),
                    'style2' => esc_html__( 'Style 2', 'rsaddon' ),
                ],                
                'separator' => 'before',
                'condition' => [
                    'blog_content_postion_style' => 'default',
                ]
            ]
        );

        $this->add_control(
            'blog_separator_show_hide',
            [
                'label' => esc_html__( 'Separator Show/Hide', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'no',
                'options' => [
                    'yes' => esc_html__( 'Yes', 'rsaddon' ),
                    'no' => esc_html__( 'No', 'rsaddon' ),
                ],                
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'blog_meta_icon_hide',
            [
                'label' => esc_html__( 'Meta Icon Show/Hide', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'yes',
                'options' => [
                    'yes' => esc_html__( 'Yes', 'rsaddon' ),
                    'no' => esc_html__( 'No', 'rsaddon' ),
                ],                
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'blog_content_show_hide',
            [
                'label' => esc_html__( 'Description Show/Hide', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'yes',
                'options' => [
                    'yes' => esc_html__( 'Yes', 'rsaddon' ),
                    'no' => esc_html__( 'No', 'rsaddon' ),
                ],                
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'blog_image_show_hide',
            [
                'label' => esc_html__( 'Image Show/Hide', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'yes',
                'options' => [
                    'yes' => esc_html__( 'Yes', 'rsaddon' ),
                    'no' => esc_html__( 'No', 'rsaddon' ),
                ],                
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'blog_word_show',
            [
                'label' => esc_html__( 'Show Content Limit', 'rsaddon' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_html__( '20', 'rsaddon' ),
                'separator' => 'before',
                'condition' => [
                    'blog_content_show_hide' => 'yes',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'large',
                'separator' => 'before',
                'exclude' => [
                    'custom'
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'align',
            [
                'label' => esc_html__( 'Alignment', 'rsaddon' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'rsaddon' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'rsaddon' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'rsaddon' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__( 'Justify', 'rsaddon' ),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item .blog-content' => 'text-align: {{VALUE}}'
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            'content_section_title',
            [
                'label' => esc_html__( 'Title Settings', 'rsaddon' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'blog_title_show_position',
            [
                'label' => esc_html__( 'Blog Title Show Above Meta', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'no',
                'options' => [
                    'title-yes' => esc_html__( 'Yes', 'rsaddon' ),
                    'no' => esc_html__( 'No', 'rsaddon' ),
                ],                
                'separator' => 'before',
            ]
        ); 

         
        $this->end_controls_section();

        $this->start_controls_section(
            'content_section_button',
            [
                'label' => esc_html__( 'Button Settings', 'rsaddon' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'blog_readmore_show_hide',
            [
                'label' => esc_html__( 'ReadMore Show/Hide', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'yes',
                'options' => [
                    'yes' => esc_html__( 'Yes', 'rsaddon' ),
                    'no' => esc_html__( 'No', 'rsaddon' ),
                ],                
                'separator' => 'before',
            ]
        ); 

        $this->add_control(
            'blog_readmore_show_hover',
            [
                'label' => esc_html__( 'Read More Show Item Hover', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'no',
                'options' => [
                    'yes' => esc_html__( 'Yes', 'rsaddon' ),
                    'no' => esc_html__( 'No', 'rsaddon' ),
                ],                
                'separator' => 'before',
            ]
        ); 


        $this->add_control(
            'blog_btn_text',
            [
                'label' => esc_html__( 'Blog Button Text', 'rsaddon' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '',
                'placeholder' => esc_html__( 'Blog Button Text', 'rsaddon' ),
                'separator' => 'before',
                'condition' => [
                    'blog_readmore_show_hide' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'blog_btn_icon',
            [
                'label' => esc_html__( 'Icon', 'rsaddon' ),
                'type' => Controls_Manager::ICON,
                'options' => rsaddon_pro_get_icons(),               
                'default' => 'ri-arrow-right-line',
                'separator' => 'before',
                'condition' => [
                    'blog_readmore_show_hide' => 'yes',
                ]           
            ]
        );
        $this->add_control(
            'blog_btn_icon_position',
            [
                'label' => esc_html__( 'Icon Position', 'rsaddon' ),
                'type' => Controls_Manager::CHOOSE,
                'label_block' => false,
                'options' => [
                    'before' => [
                        'title' => esc_html__( 'Before', 'rsaddon' ),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'after' => [
                        'title' => esc_html__( 'After', 'rsaddon' ),
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'default' => 'after',
                'toggle' => false,
                'condition' => [
                    'blog_readmore_show_hide' => 'yes',
                    'blog_btn_icon!' => '',
                ]
            ]
        ); 
        $this->add_control(
            'blog_btn_icon_spacing',
            [
                'label' => esc_html__( 'Icon Spacing', 'rsaddon' ),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 10
                ],
                'condition' => [
                    'blog_btn_icon!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn.icon-before i' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn.icon-after i' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'blog_readmore_show_hide' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'blog_btn_border',
            [
                'label' => esc_html__( 'Button Border Yes/No', 'rsaddon' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'btn_borer_no',
                'options' => [
                    'default' => esc_html__( 'Default', 'rsaddon' ),
                    'btn_borer_yes' => esc_html__( 'Yes', 'rsaddon' ),
                    'btn_borer_no' => esc_html__( 'No', 'rsaddon' ),
                ],                
                'condition' => [
                    'blog_readmore_show_hide' => 'yes',
                ]
            ]
        );    
        $this->end_controls_section();

        //start slider settings
        $this->start_controls_section(
            'section_slider_settings',
            [
                'label' => esc_html__( 'Slider Settings', 'rsaddon' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'col_lg',
            [
                'label'   => esc_html__( 'Desktops > 1199px', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 3,
                'options' => [
                    '1' => esc_html__( '1 Column', 'rsaddon' ), 
                    '2' => esc_html__( '2 Column', 'rsaddon' ),
                    '3' => esc_html__( '3 Column', 'rsaddon' ),
                    '4' => esc_html__( '4 Column', 'rsaddon' ),
                    '6' => esc_html__( '6 Column', 'rsaddon' ),                 
                ],
                'separator' => 'before',       
            ]
        );
        $this->add_control(
            'col_md',
            [
                'label'   => esc_html__( 'Desktops > 991px', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 3,         
                'options' => [
                    '1' => esc_html__( '1 Column', 'rsaddon' ), 
                    '2' => esc_html__( '2 Column', 'rsaddon' ),
                    '3' => esc_html__( '3 Column', 'rsaddon' ),
                    '4' => esc_html__( '4 Column', 'rsaddon' ),
                    '6' => esc_html__( '6 Column', 'rsaddon' ),                     
                ],
                'separator' => 'before',            
            ]
        );
        $this->add_control(
            'col_sm',
            [
                'label'   => esc_html__( 'Tablets > 767px', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 2,         
                'options' => [
                    '1' => esc_html__( '1 Column', 'rsaddon' ), 
                    '2' => esc_html__( '2 Column', 'rsaddon' ),
                    '3' => esc_html__( '3 Column', 'rsaddon' ),
                    '4' => esc_html__( '4 Column', 'rsaddon' ),
                    '6' => esc_html__( '6 Column', 'rsaddon' ),                 
                ],
                'separator' => 'before',            
            ] 
        );
        $this->add_control(
            'col_xs',
            [
                'label'   => esc_html__( 'Tablets < 768px', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 1,         
                'options' => [
                    '1' => esc_html__( '1 Column', 'rsaddon' ), 
                    '2' => esc_html__( '2 Column', 'rsaddon' ),
                    '3' => esc_html__( '3 Column', 'rsaddon' ),
                    '4' => esc_html__( '4 Column', 'rsaddon' ),
                    '6' => esc_html__( '6 Column', 'rsaddon' ),                 
                ],
                'separator' => 'before',        
            ]
        );

        $this->add_control(
            'slides_ToScroll',
            [
                'label'   => esc_html__( 'Slide To Scroll', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 2,         
                'options' => [
                    '1' => esc_html__( '1 Item', 'rsaddon' ),
                    '2' => esc_html__( '2 Item', 'rsaddon' ),
                    '3' => esc_html__( '3 Item', 'rsaddon' ),
                    '4' => esc_html__( '4 Item', 'rsaddon' ),                   
                ],
                'separator' => 'before',   
            ]
        );
        $this->add_control(
            'slider_dots',
            [
                'label'   => esc_html__( 'Navigation Dots', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 'false',
                'options' => [
                    'true' => esc_html__( 'Enable', 'rsaddon' ),
                    'false' => esc_html__( 'Disable', 'rsaddon' ),              
                ],
                'separator' => 'before',    
            ]
        );
        $this->add_control(
            'dots_bg',
            [
                'label' => esc_html__( 'Dots Bg Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-dots li button, 
                    {{WRAPPER}} .rs-testimonial-dots-style2 .slick-dots li button' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'slider_dots' => 'true',
                ],
            ]
        );

        $this->add_control(
            'dots_bg_active',
            [
                'label' => esc_html__( 'Dots Bg Active Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-dots li.slick-active button, 
                    {{WRAPPER}} .rs-testimonial-dots-style2 .slick-dots li.slick-active button' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'slider_dots' => 'true',
                ],
            ]
        );
        $this->add_control(
            'dots_bg__bord',
            [
                'label' => esc_html__( 'Border Radius', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .rs-testimonial-dots-style2 .slick-dots li button, {{WRAPPER}} .rs-addon-slider .slick-dots li button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'slider_nav',
            [
                'label'   => esc_html__( 'Navigation Nav', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 'false',           
                'options' => [
                    'true' => esc_html__( 'Enable', 'rsaddon' ),
                    'false' => esc_html__( 'Disable', 'rsaddon' ),              
                ],
                'separator' => 'before',          
            ]
        );

        $this->add_control(
            'slider_autoplay',
            [
                'label'   => esc_html__( 'Autoplay', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 'false',           
                'options' => [
                    'true' => esc_html__( 'Enable', 'rsaddon' ),
                    'false' => esc_html__( 'Disable', 'rsaddon' ),              
                ],
                'separator' => 'before',        
            ]
        );

        $this->add_control(
            'slider_autoplay_speed',
            [
                'label'   => esc_html__( 'Autoplay Slide Speed', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 3000,          
                'options' => [
                    '1000' => esc_html__( '1 Seconds', 'rsaddon' ),
                    '2000' => esc_html__( '2 Seconds', 'rsaddon' ), 
                    '3000' => esc_html__( '3 Seconds', 'rsaddon' ), 
                    '4000' => esc_html__( '4 Seconds', 'rsaddon' ), 
                    '5000' => esc_html__( '5 Seconds', 'rsaddon' ), 
                ],
                'separator' => 'before',        
            ]
        );

        $this->add_control(
            'slider_stop_on_hover',
            [
                'label'   => esc_html__( 'Stop on Hover', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',               
                'options' => [
                    'true' => esc_html__( 'Enable', 'rsaddon' ),
                    'false' => esc_html__( 'Disable', 'rsaddon' ),              
                ],
                'separator' => 'before',
                            
            ]
        );

        $this->add_control(
            'slider_interval',
            [
                'label'   => esc_html__( 'Autoplay Interval', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 3000,          
                'options' => [
                    '5000' => esc_html__( '5 Seconds', 'rsaddon' ), 
                    '4000' => esc_html__( '4 Seconds', 'rsaddon' ), 
                    '3000' => esc_html__( '3 Seconds', 'rsaddon' ), 
                    '2000' => esc_html__( '2 Seconds', 'rsaddon' ), 
                    '1000' => esc_html__( '1 Seconds', 'rsaddon' ),     
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_loop',
            [
                'label'   => esc_html__( 'Loop', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',
                'options' => [
                    'true' => esc_html__( 'Enable', 'rsaddon' ),
                    'false' => esc_html__( 'Disable', 'rsaddon' ),
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_centerMode',
            [
                'label'   => esc_html__( 'Center Mode', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',
                'options' => [
                    'true' => esc_html__( 'Enable', 'rsaddon' ),
                    'false' => esc_html__( 'Disable', 'rsaddon' ),
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->end_controls_section(); //end slider settings


        $this->start_controls_section(
            'section_slider_style',
            [
                'label' => esc_html__( 'Blog Style', 'rsaddon' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'gradient_style_select',
            [
                'label'   => esc_html__( 'Gradient Enable/Disable', 'rsaddon' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'disable',
                'options' => [
                    'enable' => esc_html__( 'Enable', 'rsaddon' ),
                    'disable' => esc_html__( 'Disable', 'rsaddon' ),
                ],
                'separator' => 'before',
            ]
        );




        $this->add_control(
            'meta_color_gradinet_heading',
            [
				'label' => esc_html__( 'Meta Color', 'rsaddon' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
                'condition' => [
                    'gradient_style_select' => 'enable',
                ] 
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'meta_color_gradinet',
                'label' => esc_html__( 'Background', 'rsaddon' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .btm-rs .blog-footer .blog-meta li, {{WRAPPER}} .btm-rs .blog-footer .blog-meta .cat_list.btm ul li a',
                'condition' => [
                    'gradient_style_select' => 'enable',
                ] 
            ]
        );

        $this->add_control(
            'meta_date_color',
            [
                'label' => esc_html__( 'Meta Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btm-rs .blog-footer .blog-meta li, {{WRAPPER}} .btm-rs .blog-footer .blog-meta .cat_list.btm ul li a' => 'color: {{VALUE}};',
                ],
                'separator' => 'before',
                'condition' => [
                    'gradient_style_select' => 'disable',
                ] 
            ]
        );

        $this->add_control(
            'meta_hover_date_color',
            [
                'label' => esc_html__( 'Meta Hover Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .transparent .blog-inner-wrap:hover .blog-meta .cat_list.btm ul li a, {{WRAPPER}} .transparent .blog-inner-wrap:hover .blog-meta li, {{WRAPPER}} .btm-rs .blog-footer .blog-meta .cat_list.btm ul li a:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .blog-style4:hover .blog-footer .blog-meta li' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .blog-style4:hover .blog-footer .blog-meta .cat_list.btm ul li a' => 'color: {{VALUE}};',
                ],                
            ]
        );

        $this->add_control(
            'meta_icon_color',
            [
                'label' => esc_html__( 'Meta Icon Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rsaddon-unique-slider .blog-content .blog-footer .blog-meta i' => 'color: {{VALUE}};',
                ], 
                'condition' => [
                    'blog_meta_icon_hide' => 'yes',
                ]               
            ]
        );


        


        $this->add_control(
            'meta_separator_color',
            [
                'label' => esc_html__( 'Meta Separator Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btm-rs .blog-footer .blog-meta.sep-yes li:after' => 'background: {{VALUE}};',

                ], 
                'condition' => [
                    'blog_separator_show_hide' => 'yes',
                ]               
            ]
        );

        $this->add_control(
            'meta_all_bg_color',
            [
                'label' => esc_html__( 'Meta Bg Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2.slick-slide .blog-meta' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2.slick-slide .blog-meta:after' => 'border-bottom-color: {{VALUE}};',
                ],
                'condition' => [
                    'blog_content_postion_style' => 'blog_style_2',
                ]                
            ]
        );

        $this->add_responsive_control(
			'blog_meta_data_padding',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Meta Padding', 'rsaddon' ),
				'selectors' => [
					'{{WRAPPER}} .rs-blog-grid .blog-item .blog-content .blog-meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'blog_meta_data_margin',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Meta Margin', 'rsaddon' ),
				'selectors' => [
					'{{WRAPPER}} .rs-blog-grid .blog-item .blog-content .blog-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'meta_text_typography',
                'label' => esc_html__( 'Category Text Typography', 'rsaddon' ),
                'selector' => 
                    '{{WRAPPER}} .btm-rs .blog-footer .blog-meta .cat_list.btm ul li a, {{WRAPPER}} .btm-rs .blog-footer .blog-meta li',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'date_text_typography',
                'label' => esc_html__( 'Date Text Typography', 'rsaddon' ),
                'selector' => 
                    '{{WRAPPER}} .rs-blog-grid .blog-item.transparent .blog-inner-wrap .blog-content .blog-meta .blog_day',
            ]
        );

        $this->add_control(
            'date_color',
            [
                'label' => esc_html__( 'Date Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rsaddon-unique-slider .image-wrap .date' => 'color: {{VALUE}};',
                ],    
                'condition' => [
                    'blog_content_postion_style' => 'default',
                ],
            ]
        );

        $this->add_control(
            'separetor_dot_bg',
            [
                'label' => esc_html__( 'Separator Dot Background', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rsaddon-unique-slider ul.blog-meta li:after' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'gradient_style_select' => 'disable',
                ],
            ]
        );

        $this->add_control(
            'separetor_dot_heading',
            [
                'label' => esc_html__( 'Separator Dot Background', 'rsaddon' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'gradient_style_select' => 'enable',
                ],
            ]
        );

        $this->add_group_control(
           Group_Control_Background::get_type(),
           [
                'name' => 'separetor_dot_gradient_bg',
                'label' => esc_html__( 'Background Color', 'rsaddon' ),
                'types' => [ 'classic', 'gradient' ],
                'blog_content_postion_style' => 'default',
                'selector' => '{{WRAPPER}} .rsaddon-unique-slider ul.blog-meta li:after',
                'condition' => [
                    'gradient_style_select' => 'enable',
                ],
           ]
        );

        $this->add_control(
            'author_meta_custom_icon_title',
            [
                'label' => esc_html__( 'Author Icon', 'rsaddon' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'blog_content_postion_style' => 'blog_style_5',
                    'blog_avatar_icon_show' => 'yes',
                    'blog_avatar_show_hide' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'author_meta_icon_color',
            [
                'label' => esc_html__( 'Icon Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'blog_content_postion_style' => 'blog_style_5',
                    'blog_avatar_icon_show' => 'yes',
                    'blog_avatar_show_hide' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .blog-meta .admin i' => 'color: {{VALUE}};',

                ],             
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'author_meta_icon_typography',
                'label' => esc_html__( 'Icon Typography', 'rsaddon' ),
                'condition' => [
                    'blog_content_postion_style' => 'blog_style_5',
                    'blog_avatar_icon_show' => 'yes',
                    'blog_avatar_show_hide' => 'yes',
                ],
                'selector' => 
                    '{{WRAPPER}} .blog-meta .admin i',
            ]
        );
        $this->add_control(
            'author_meta_icon_margin',
             [
                'label' => esc_html__( 'Icon Spacing', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'condition' => [
                    'blog_content_postion_style' => 'blog_style_5',
                    'blog_avatar_icon_show' => 'yes',
                    'blog_avatar_show_hide' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .blog-meta .admin i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 ],
             ]
         );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'author_and_category_border_for_style_five',
                'selector' => '{{WRAPPER}} .blog-meta',
                'condition' =>[
                    'blog_content_postion_style'=>'blog_style_5',
                ],
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Title Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-content h3.blog-name a' => 'color: {{VALUE}};',

                ],  
                'separator' => 'before',              
            ]
        );

        $this->add_control(
            'title_color_hover',
            [
                'label' => esc_html__( 'Title Hover Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .transparent .blog-inner-wrap:hover .blog-content h3.blog-name a, {{WRAPPER}} .blog-item .blog-content h3.blog-name a:hover' => 'color: {{VALUE}};',
                    '.rs-blog-grid .blog-content.blog-style4 h3.blog-name a:hover' => 'color: {{VALUE}};',
                ],                
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => esc_html__( 'Title Typography', 'rsaddon' ),
                'selector' => 
                    '{{WRAPPER}} .blog-item .blog-content h3.blog-name a',
            ]
        );

        $this->add_responsive_control(
            'blog_title_margin',
            [
                'label' => esc_html__( 'Margin', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'range' => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 30,
                ],  
                'selectors' => [
                    '{{WRAPPER}} .blog-content h3.blog-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'blog_title_padding',
            [
                'label' => esc_html__( 'Padding', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'range' => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 30,
                ],  
                'selectors' => [
                    '{{WRAPPER}} .blog-content h3.blog-name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'media_border_title',
                'selector' => '{{WRAPPER}} .blog-content',
            ]
        );

        $this->add_responsive_control(
            'blog_desc_padding',
            [
                'label' => esc_html__( 'Description Padding', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'range' => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 30,
                ],  
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item.default .blog-content p, {{WRAPPER}} .rs-blog-grid .blog-item .blog-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'blog_image_margin',
            [
                'label' => esc_html__( 'Image Margin', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'range' => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 30,
                ],  
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item .image-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'image_border_radius',
            [
                'label' => esc_html__( 'Image Border Radius', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item .image-wrap img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__( 'Content Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content p' => 'color: {{VALUE}};',
                ],    
                'separator' => 'before',            
            ]
        );
        

        $this->add_control(
            'content_border_radius',
            [
                'label' => esc_html__( 'Content Border Radius', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item .blog-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'content_color_hover',
            [
                'label' => esc_html__( 'Content Hover Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .transparent .blog-inner-wrap:hover .blog-content p' => 'color: {{VALUE}};',
                ],    
                'separator' => 'before',   
                'condition' => [
                    'blog_content_postion_style' => 'transparent',
                ],         
            ]
        );

        $this->add_responsive_control(
            'blog_content_padding',
            [
                'label' => esc_html__( 'Padding', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'range' => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 30,
                ],  
                'selectors' => [
                    '{{WRAPPER}} .blog-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'blog_bottom_spacing',
            [
                'label' => esc_html__( 'Bottom Spacing', 'rsaddon' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_shadow',
                'label' => esc_html__( 'Box Shadow', 'plugin-domain' ),
                'selector' => '{{WRAPPER}} .rs-blog-grid .rs-addon-slider .blog-item .blog-inner-wrap',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => esc_html__( 'Content Background', 'plugin-domain' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .blog-item .blog-content',
                
            ]
        );

        $this->add_control(
            'blog_btm_shape_color',
            [
                'label' => esc_html__( 'Shape Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'blog_content_postion_style' => 'blog_style_2',
                ],
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-services.services-style5:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .rs-addon-services.services-style5:after' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'blog_btm_hover_shape_color',
            [
                'label' => esc_html__( 'Shape Hover Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'blog_content_postion_style' => 'blog_style_2',
                ],
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2 .blog-inner-wrap:before, {{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2:hover:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2:hover:after'  => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'blog_area_content_padding',
            [
                'label' => esc_html__( 'Blog Area Padding', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'range' => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 30,
                ],  
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item .blog-inner-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'blog_area_content_margn',
            [
                'label' => esc_html__( 'Blog Area Margin', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'range' => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 30,
                ],  
                'selectors' => [
                    '{{WRAPPER}} div.rs-blog-grid .blog-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'blog_area_content_bg',
            [
                'label' => esc_html__( 'Blog Area Background', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item.transparent .blog-inner-wrap .image-wrap:before, {{WRAPPER}} .rs-blog-grid .blog-item .blog-inner-wrap' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'blog_hoverbg_title',
            [
                'label' => esc_html__( 'Blog Hover Background', 'rsaddon' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

         $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'blog_hover_bg',
                'label' => esc_html__( 'Content Hover Background', 'rsaddon' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'condition' => [
                    'blog_content_postion_style' => 'transparent',
                ],
                'selector' => '{{WRAPPER}} .rs-blog-grid .blog-item.transparent .blog-inner-wrap:hover .image-wrap::before',
                
            ]
        );

        $this->add_control(
            'item_border_radius',
            [
                'label' => esc_html__( 'Item Border Radius', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-inner-wrap ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'blog_area_box_shadow',
                'selector' => '{{WRAPPER}} .rs-blog-grid .blog-inner-wrap ',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'media_border',
                'selector' => '{{WRAPPER}} .rs-blog-grid .blog-item .blog-inner-wrap',
            ]
        );
        $this->add_responsive_control(
            'blog_area_content_hover_bg',
            [
                'label' => esc_html__( 'Blog Hover Background', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-content.blog-style4:hover' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();


        //Cate Style
        $this->start_controls_section(
            '_section_style_catess',
            [
                'label' => esc_html__( 'Category Style', 'rsaddon' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'category_color',
            [
                'label' => esc_html__( 'Category Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btm-rs .blog-footer .blog-meta .cat_list.btm ul li a => color: {{VALUE}};,
                    {{WRAPPER}} .rs-blog-grid .blog-item .image-wrap .cat_list ul li a' => 'color: {{VALUE}};',
                ],                  
            ]
        );

        $this->add_control(
            'category_hover',
            [
                'label' => esc_html__( 'Category Hover Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btm-rs .blog-footer .blog-meta .cat_list.btm ul li a:hover, {{WRAPPER}} .rs-blog-grid .blog-item .image-wrap .cat_list ul li a:hover' => 'color: {{VALUE}};',

                ],                
            ]
        );
       
        $this->add_control(
           'cate_border_radius',
            [
               'label' => esc_html__( 'Category Border Radius', 'rsaddon' ),
               'type' => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px', '%' ],
               'selectors' => [
                   '{{WRAPPER}} .rs-blog-grid .image-wrap .date, {{WRAPPER}} .rs-blog-grid .blog-item .image-wrap .cat_list ul li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'cat_typography',
                'selector' => '{{WRAPPER}} .btm-rs .blog-footer .blog-meta .cat_list.btm ul li a, {{WRAPPER}} .rs-blog-grid .blog-item .image-wrap .cat_list ul li a',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'cat_border',
                'selector' => '{{WRAPPER}} .rs-blog-grid .blog-item .blog-content .blog-meta',
            ]
        );

        $this->add_responsive_control(
            'cat_area_horizontal_position',
            [
                'label' => esc_html__( 'Category Area Horizontal Position', 'rsaddon' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
					'px' => [
						'min' => -100,
						'max' => 1000,
						'step' => 1,
					],
				],
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item .blog-content .blog-meta' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'cat_right_spacing',
            [
                'label' => esc_html__( 'Category Right Spacing', 'rsaddon' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
					'px' => [
						'min' => -100,
						'max' => 1000,
						'step' => 1,
					],
				],
                // 'selectors' => [
                //     '{{WRAPPER}} .rsaddon-unique-slider ul.blog-meta li' => 'padding-right: {{SIZE}}{{UNIT}};',
                // ],
                'selectors' => [
                    '{{WRAPPER}} .btm-rs .blog-footer .blog-meta.sep-yes li' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'backgroundcate',
                'label' => __( 'Background', 'plugin-domain' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .rs-blog-grid .blog-item .image-wrap .cat_list ul li a',
            ]
        );

        $this->add_responsive_control(
			'blog_category_padding',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Meta Padding', 'textdomain' ),
				'selectors' => [
					'{{WRAPPER}} .rs-blog-grid .blog-item .image-wrap .cat_list ul' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        //Read More Style
        $this->start_controls_section(
            '_section_style_button',
            [
                'label' => esc_html__( 'Read More Style', 'rsaddon' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'blog_readmore_show_hide' => 'yes',
                ]
            ]
        );

        $this->add_responsive_control(
            'blog_btn_link_padding',
            [
                'label' => esc_html__( 'Padding', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn, {{WRAPPER}} .blog-item .blog-content .custom-blog-btn, {{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2.slick-slide .blog-content .blog-btn-part2 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->add_responsive_control(
            'margin_btn',
            [
                'label' => esc_html__( 'Margin', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn-part, {{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2.slick-slide .blog-content .blog-btn-part2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'btn_typography',
                'selector' => '{{WRAPPER}} .blog-item .blog-content .blog-btn, {{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2.slick-slide .blog-content .blog-btn-part2 a',
            ]
        );

        $this->add_control(
            'blog_btn_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn, {{WRAPPER}} .blog-item .blog-content .custom-blog-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} .blog-item .blog-content .blog-btn',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'blog_btn_box_shadow',
                'selector' => '{{WRAPPER}} .blog-item .blog-content .blog-btn',
            ]
        );

        $this->add_control(
            'hr',
            [
                'type' => Controls_Manager::DIVIDER,
                'style' => 'thick',
            ]
        );

        $this->start_controls_tabs( '_tabs_button' );

        $this->start_controls_tab(
            '_blog_btn_normal',
            [
                'label' => esc_html__( 'Normal', 'rsaddon' ),
            ]
        );



        $this->add_control(
            'btn_color_gradinet_heading',
            [
				'label' => esc_html__( 'Button  Color', 'rsaddon' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
                'condition' => [
                    'gradient_style_select' => 'enable',
                ] 
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'link_color_gradient',
                'label' => esc_html__( 'Background', 'rsaddon' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .gradient-style-enable .blog-item .blog-content .blog-btn:not(:hover) i::before, {{WRAPPER}} .blog-item .blog-content .blog-btn:not(:hover) span, {{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2.slick-slide .blog-content .blog-btn-part2 a .custom-blog-btn:not(:hover) span',
                'condition' => [
                    'gradient_style_select' => 'enable',
                ] 
            ]
        );

        $this->add_control(
            'link_color',
            [
                'label' => esc_html__( 'Text Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .blog-item .blog-content  .custom-blog-btn' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2.slick-slide .blog-content .blog-btn-part2 a .custom-blog-btn' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .rs-blog-grid.gradient-style-enable .blog-content .blog-btn-part a.blog-btn' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'gradient_style_select' => 'disable',
                ] 
            ]
        );

        $this->add_control(
            'icon_border_color',
            [
                'label' => esc_html__( 'Icon Border Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item .blog-content .blog-btn-part .blog-btn.icon-after i' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'circle_background',
            [
                'label' => esc_html__( 'Button Circle Dots Background', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,            
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item .blog-content .blog-btn-part .blog-btn:after' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'blog_btn_bg_color',
            [
                'label' => esc_html__( 'Background Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'gradient_style_select' => 'disable',
                ],
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn, {{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2.slick-slide .blog-content .blog-btn-part2 a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'blog_btn_bg_color_inner',
            [
                'label' => esc_html__( 'Background Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid.gradient-style-enable .blog-content .blog-btn-part a.blog-btn:before' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'gradient_style_select' => 'enable',
                ],
            ]
        );

        $this->add_control(
            'button_position',
            [
                'label' => esc_html__( 'Button Position', 'rsaddon' ),
                'type' => Controls_Manager::SLIDER,
                'show_label' => true,               
                'range' => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                        

                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content  .blog-btn-part2' => 'margin-top:-{{SIZE}}{{UNIT}};',                    
                ],
            ]
        ); 

        $this->add_control(
            'blog_btn_icon_translate',
            [
                'label' => esc_html__( 'Icon Translate X', 'rsaddon' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn.icon-before i' => '-webkit-transform: translateX(calc(-1 * {{SIZE}}{{UNIT}})); transform: translateX(calc(-1 * {{SIZE}}{{UNIT}}));',
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn.icon-after i' => '-webkit-transform: translateX({{SIZE}}{{UNIT}}); transform: translateX({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'icon_button_border',
                'selector' => '{{WRAPPER}} .blog-item .blog-content .blog-btn.icon-after i',
            ]
        );

        $this->add_control(
            'icon_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn.icon-after i, {{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2.slick-slide .blog-content .blog-btn-part2 a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'btn_icon_padding',
            [
                'label' => esc_html__( 'Padding', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn.icon-after i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'btn_border_title',
            [
                'label' => __( 'Button Border Bg Color', 'rsaddon' ),
                'type' => Controls_Manager::HEADING,
                'placeholder' => __( 'Enter your title', 'rsaddon' ),
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'btn_border_backgrounds',
                'label' => esc_html__( 'Button Border Color', 'rsaddon' ),
                'types' => [ 'classic', 'gradient'],
                'selector' => '{{WRAPPER}} .rs-blog-grid .blog-item .blog-content .btn_borer_yes a:after',
                'condition' => [
                    'blog_readmore_show_hide' => 'yes',
                    'gradient_style_select' => 'disable',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'sas_btn_border_background_gradient_two',
                'label' => esc_html__( 'Button Border Color', 'rsaddon' ),
                'types' => [ 'classic', 'gradient'],
                'selector' => '{{WRAPPER}} .rs-blog-grid.gradient-style-enable .blog-content .blog-btn-part a.blog-btn',
                'condition' => [
                    'blog_readmore_show_hide' => 'yes',
                    'gradient_style_select' => 'enable',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            '_blog_btn_button_hover',
            [
                'label' => esc_html__( 'Hover', 'rsaddon' ),
            ]
        );

        $this->add_control(
            'blog_btn_hover_colors',
            [
                'label' => esc_html__( 'Text Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .transparent .blog-inner-wrap:hover .blog-btn, {{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2.slick-slide:hover .blog-content .blog-btn-part2 a, {{WRAPPER}} .blog-item .blog-content .blog-btn:hover, {{WRAPPER}} .blog-item .blog-content .custom-blog-btn:hover, {{WRAPPER}} .blog-item .blog-content .blog-btn:hover, {{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2.slick-slide:hover .blog-content .blog-btn-part2 a .custom-blog-btn,{{WRAPPER}} .rs-blog-grid.gradient-style-enable .blog-content .blog-btn-part a.blog-btn' => 'color: {{VALUE}};',
                   
                ],
            ]
        );

        $this->add_control(
            'blog_btn_hover_bg_color',
            [
                'label' => esc_html__( 'Background Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn:hover, {{WRAPPER}} .rs-blog-grid .blog-item.blog_style_2.slick-slide .blog-content .blog-btn-part2 a:hover' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} '
                ],
                'condition' => [
                    'gradient_style_select' => 'disable',
                ],
            ]
        );

        $this->add_control(
            'blog_btn_hover_bg_color_gradient_styled',
            [
                'label' => esc_html__( 'Background Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid.gradient-style-enable .blog-content .blog-btn-part a.blog-btn:hover:before' => 'background: {{VALUE}};',
                ],
                'condition' => [
                    'gradient_style_select' => 'enable',
                ],
            ]
        );

        $this->add_control(
            'blog_btn_hover_border_color',
            [
                'label' => esc_html__( 'Border Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'button_border_border!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn:hover, {{WRAPPER}} .blog-item .blog-content .blog-btn:focus' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_hover_color',
            [
                'label' => esc_html__( 'Icon Hover Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item .blog-content .blog-btn-part .blog-btn.icon-after:hover i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_border_hover_color',
            [
                'label' => esc_html__( 'Icon Border Hover Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .rs-blog-grid .blog-item .blog-content .blog-btn-part .blog-btn.icon-after:hover i' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'icon_button_border_hover',
                'selector' => '{{WRAPPER}} .blog-item .blog-content .blog-btn.icon-after:hover i',
            ]
        );

        $this->add_control(
            'icon_border_hover_color_bg',
            [
                'label' => esc_html__( 'Icon Hover Background Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn.icon-after:hover i' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'blog_btn_hover_icon_translate',
            [
                'label' => esc_html__( 'Icon Translate X', 'rsaddon' ),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 10
                ],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn.icon-before:hover i' => '-webkit-transform: translateX(calc(-1 * {{SIZE}}{{UNIT}})); transform: translateX(calc(-1 * {{SIZE}}{{UNIT}}));',
                    '{{WRAPPER}} .blog-item .blog-content .blog-btn.icon-after:hover i' => '-webkit-transform: translateX({{SIZE}}{{UNIT}}); transform: translateX({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_control(
            'btn_border_title_hover',
            [
                'label' => __( 'Button Border Bg Color Hover', 'rsaddon' ),
                'type' => Controls_Manager::HEADING,
                'placeholder' => __( 'Enter your title', 'rsaddon' ),
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'sasly_btn_border_background_gradient_hovers',
                'label' => esc_html__( 'Button Border Color', 'rsaddon' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .rs-blog-grid.gradient-style-enable .blog-content .blog-btn-part a.blog-btn:hover',
                'condition' => [
                    'blog_readmore_show_hide' => 'yes',
                    'gradient_style_select' => 'enable',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();


        // Nav And Dot Style Start
        $this->start_controls_section(
            'section_arrow_bullet_style',
            [
                'label' => esc_html__( 'Slider Controller Style', 'rsaddon' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // Arrow Start
        $this->add_control(
            'arrow_color',
            [
                'label' => esc_html__( 'Arrow Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rsaddon-unique-slider .slick-arrow:before' => 'color: {{VALUE}};',  
                ],                
            ]
        );

        $this->add_control(
            'arrow_bg_color',
            [
                'label' => esc_html__( 'Arrow Background Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rsaddon-unique-slider .rs-addon-slider .slick-arrow' => 'background: {{VALUE}};',  
                ],                
            ]
        );
        
        $this->add_control(
            'arrow_hover_color',
            [
                'label' => esc_html__( 'Arrow Hover Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rsaddon-unique-slider .slick-arrow:hover:before' => 'color: {{VALUE}};',  
                ],                
            ]
        );

        $this->add_control(
            'arrow_hover_bg_color',
            [
                'label' => esc_html__( 'Arrow Hover Background Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rsaddon-unique-slider .slick-arrow:hover' => 'background: {{VALUE}};',  
                ],                
            ]
        );

        $this->add_responsive_control(
            'arrow_font_size',
            [
                'label' => esc_html__( 'Arrow Font Size', 'rsaddon' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 0,
                        'max' => 5000,
                    ],
                ],
               
                'selectors' => [
                    '{{WRAPPER}} .rsaddon-unique-slider .slick-arrow:before' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                
            ]
        );

        $this->add_responsive_control(
            'arrows_tops_positions',
            [
                'label'      => esc_html__( 'Top Position', 'rsaddon' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    'px' => [
                        'min' => -5000,
                        'max' => 5000,
                    ],
                ],
             
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-prev, {{WRAPPER}} .rs-testimonial .rs-testimonial-dots-style2 .slick-prev, {{WRAPPER}} .rs-testimonial .rs-addon-slider .slick-prev' => 'top: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );  

        $this->add_responsive_control(
            'arrows_lefts_positions',
            [
                'label'      => esc_html__( 'Left Position', 'rsaddon' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    'px' => [
                        'min' => -5000,
                        'max' => 5000,
                    ],
                ],
             
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-prev, {{WRAPPER}} .rs-testimonial .rs-testimonial-dots-style2 .slick-prev, {{WRAPPER}} .rs-testimonial .rs-addon-slider .slick-prev' => 'left: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );  

        $this->add_responsive_control(
            'arrow_tos_positions',
            [
                'label'      => esc_html__( 'Top Position', 'rsaddon' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    'px' => [
                        'min' => -5000,
                        'max' => 5000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-next, {{WRAPPER}} .rs-testimonial .rs-testimonial-dots-style2 .slick-next, {{WRAPPER}} .rs-testimonial .rs-addon-slider .slick-next' => 'top: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'arrows_rights_positions',
            [
                'label'      => esc_html__( 'Right Position', 'rsaddon' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    'px' => [
                        'min' => -5000,
                        'max' => 5000,
                    ],
                ],          
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-next, {{WRAPPER}} .rs-testimonial .rs-testimonial-dots-style2 .slick-next, {{WRAPPER}} .rs-testimonial .rs-addon-slider .slick-next' => 'right: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'ars_border_color',
            [
                'label' => esc_html__( 'Border Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rsaddon-unique-slider .rs-addon-slider .slick-arrow' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'testimonial_arrow_box_shadow',
                'selector' => '{{WRAPPER}} .rsaddon-unique-slider .slick-arrow',
            ]
        );

        $this->add_responsive_control(
            'arrow_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .rsaddon-unique-slider .slick-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'ars_border_hover_color',
            [
                'label' => esc_html__( 'Border Hover Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rsaddon-unique-slider .rs-addon-slider .slick-arrow:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        // Arrow End

        // Bullet Style Start
         $this->add_control(
            'bullet_options',
            [
                'label' => esc_html__( 'Bullet Style', 'rsaddon' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'align_dots',
            [
                'label' => esc_html__( 'Alignment', 'rsaddon' ),
                'type' => Controls_Manager::CHOOSE,
                'label_block' => false,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'rsaddon' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'rsaddon' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'rsaddon' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'center_align' => [
                        'title' => esc_html__( 'Top & Right Center', 'rsaddon' ),
                        'icon' => 'eicon-menu-bar',
                    ],
                   
                ],
                'selectors' => [
                    '{{WRAPPER}} .rs-testimonial .rs-addon-slider .slick-dots' => 'text-align: {{VALUE}}'
                ],
            ]
        );

        $this->add_responsive_control(
            'bullet_wrap_padding',
            [
                'label' => esc_html__( 'Padding', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .rs-testimonial .rs-addon-slider .slick-dots' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'bullet_spacing_custom',
            [
                'label' => esc_html__( 'Top Gap', 'rsaddon' ),
                'type' => Controls_Manager::SLIDER,
                'show_label' => true,               
                'range' => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 25,
                ],          
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-dots' => 'margin-bottom: {{SIZE}}{{UNIT}};',                    
                ],
            ]
        );
        // Bullet Style End

        $this->start_controls_tabs( '_tabs_slider_dots' );

        // Normal Bullet Start
        $this->start_controls_tab(
            'slider_dots_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'rsaddon' ),
            ]
        );

        $this->add_control(
            'navigation_dot_icon_background',
            [
                'label' => esc_html__( 'Background Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-dots li button' => 'background: {{VALUE}};',

                ],                
            ]
        );

        $this->add_responsive_control(
            'bullet_height_custom',
            [
                'label' => esc_html__( 'Bullet Height', 'rsaddon' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-dots li button' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'bullet_normal_width_custom',
            [
                'label' => esc_html__( 'Bullet Width', 'rsaddon' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-dots li button' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'bullet_border_radius_custom',
            [
                'label' => esc_html__( 'Border Radius', 'rsaddon' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-dots li button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'bullet_border_custom',
                'selector' => '{{WRAPPER}} .rs-addon-slider .slick-dots li button',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'bullet_shadow_custom',
                'selector' => '{{WRAPPER}} .rs-addon-slider .slick-dots li button'
            ]
        );

        $this->end_controls_tab();
        // Normal Bullet End

        // Active Bullet Start
        $this->start_controls_tab(
            'slider_dots_active_tab',
            [
                'label' => esc_html__( 'Active', 'rsaddon' ),
            ]
        );

        $this->add_control(
            'navigation_dot_icon_background_active',
            [
                'label' => esc_html__( 'Background Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-dots li button:hover' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .rs-addon-slider .slick-dots li.slick-active button' => 'background: {{VALUE}};',

                ],                
            ]
        );

        $this->add_responsive_control(
            'bullet_active_width_custom',
            [
                'label' => esc_html__( 'Bullet Width', 'rsaddon' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-dots li button:hover' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .rs-addon-slider .slick-dots li.slick-active button' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'navigation_dot_active_border_color',
            [
                'label' => esc_html__( 'Border Color', 'rsaddon' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .rs-addon-slider .slick-dots li button:hover' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .rs-addon-slider .slick-dots li.slick-active button' => 'border-color: {{VALUE}};',

                ],                
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        // Active Bullet End

        $this->end_controls_section();

    }

    /**
     * Render rsgallery widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $settings = $this->get_settings_for_display(); 

        $slidesToShow    = !empty($settings['col_lg']) ? $settings['col_lg'] : 3;
        $autoplaySpeed   = $settings['slider_autoplay_speed'];
        $interval        = $settings['slider_interval'];
        $slidesToScroll  = $settings['slides_ToScroll'];
        $slider_autoplay = $settings['slider_autoplay'] === 'true' ? 'true' : 'false';
        $pauseOnHover    = $settings['slider_stop_on_hover'] === 'true' ? 'true' : 'false';
        $sliderDots      = $settings['slider_dots'] == 'true' ? 'true' : 'false';
        $sliderNav       = $settings['slider_nav'] == 'true' ? 'true' : 'false';        
        $infinite        = $settings['slider_loop'] === 'true' ? 'true' : 'false';
        $centerMode      = $settings['slider_centerMode'] === 'true' ? 'true' : 'false';
        $col_lg          = $settings['col_lg'];
        $col_md          = $settings['col_md'];
        $col_sm          = $settings['col_sm'];
        $col_xs          = $settings['col_xs'];
        
        if ( is_rtl() ):
           $rtl= 'true';
        else:
           $rtl= 'false';
        endif;
       
        $unique = rand(100,31120);

        $title_postition = $settings['blog_title_show_position'];

        if(!empty($settings['align'])) {
            $align = $settings['align'];
        } else {
            $align = '';
        }

        $slider_conf = compact('slidesToShow', 'autoplaySpeed', 'interval', 'slidesToScroll', 'slider_autoplay','pauseOnHover', 'sliderDots', 'sliderNav', 'infinite', 'centerMode', 'col_lg', 'col_md', 'col_sm', 'col_xs');
        ?>
            <div class="rsaddon-unique-slider rs-blog-grid blog-grid <?php echo esc_attr($title_postition);?> <?php echo esc_html($align);?> gradient-style-<?php echo esc_attr($settings['gradient_style_select']);?>">
                <div id="rsaddon-slick-slider-<?php echo esc_attr($unique); ?>" class="rs-addon-slider" >
                    <?php 
                        $cat = $settings['category'];      
                

                        if(empty($cat)){
                            $best_wp = new wp_Query(array(
                                    'post_type'      => 'post',
                                    'posts_per_page' => $settings['per_page'],              
                            ));   
                        }   
                        else{
                            $best_wp = new wp_Query(array(
                                    'post_type'      => 'post',
                                    'posts_per_page' => $settings['per_page'],
                                    'tax_query'      => array(
                                        array(
                                            'taxonomy' => 'category',
                                            'field'    => 'term_id', 
                                            'terms'    => $cat 
                                        ),
                                    )
                            ));   
                        }
                        while($best_wp->have_posts()): $best_wp->the_post(); 
                        $full_date     = get_the_date();
                        $blog_date     = get_the_date('d M Y');   
                        $blog_day      = get_the_date('d');   
                        $blog_month    = get_the_date('M'); 
                        $post_admin    = get_the_author();
                        if(!empty($settings['blog_word_show'])){
                            $limit = $settings['blog_word_show'];
                        }
                        else{
                            $limit = 20;
                        } 

                        $user = wp_get_current_user();

                        $thumbnail_id = get_post_thumbnail_id();
                        $thumbnail_alt = get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true );
                        if ( empty( $thumbnail_alt ) ) {
                            $thumbnail_alt = get_the_title( $thumbnail_id );
                        }
                        
                        ?>
                        
                        <div class="blog-item <?php echo esc_html($settings['blog_content_postion_style']);?> hover-btn-<?php echo esc_html($settings['blog_readmore_show_hover']);?>">
                            <div class="blog-inner-wrap ">
                                <div class="image-wrap">
                                    <?php if(($settings['blog_image_show_hide'] == 'yes') ){ ?>
                                        <a class="pointer-events" href="<?php the_permalink();?>">
                                            <?php echo wp_get_attachment_image( $thumbnail_id, $settings['thumbnail_size'], false, ['alt' => $thumbnail_alt] ); ?>
                                        </a> 
                                    <?php } ?>

                                    <?php if(($settings['blog_cat_postion_style'] == 'top') ){ ?>

                                    <?php if(($settings['blog_cat_show_hide'] == 'yes') ){ ?>
                                        <div class="cat_list">
                                            <?php the_category( ); ?>
                                        </div>
                                    <?php } } ?>

                                    <?php if(($settings['blog_meta_show_hide'] == 'yes') ){ ?>

                                        <?php if(($settings['date_style'] == 'style2') ){ ?>
                                        
                                        <div class="date date_style2">
                                            <span class="blog_day"><?php echo esc_html($blog_day); ?></span>
                                            <span class="blog_month"><?php echo esc_html($blog_month); ?></span>
                                        </div>
                                        <?php } else{ ?>
                                            <div class="date">
                                            <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                            <i class="fi fi-rr-time-add" aria-hidden="true"></i>
                                            <?php echo esc_html($blog_date);} ?>
                                        </div>
                                        <?php } ?>

                                    <?php } ?>
                                </div>

                                <?php if(($settings['blog_content_postion_style'] == 'transparent_2')){ ?>
                                    <div class="blog-content">
                                        <?php if(($settings['blog_readmore_show_hide'] == 'yes') ){ ?>
                                            <?php if(!empty($settings['blog_btn_text'])){ ?>
                                                <div class="blog-btn-part">
                                                    <?php  
                                                        $icon_position = $settings['blog_btn_icon_position'] == 'before' ? 'icon-before' : 'icon-after';
                                                    ?>
                                                        <a class="blog-btn <?php echo esc_attr($icon_position) ?>" href="<?php the_permalink(); ?>">
                                                            <span class="btn-txt"><?php echo esc_html($settings['blog_btn_text']);?></span>
                                                            <?php if(!empty($settings['blog_btn_icon'])) : ?>
                                                                <i class="<?php echo esc_html($settings['blog_btn_icon']);?>"></i>
                                                            <?php endif; ?>
                                                        </a>

                                                </div>
                                            <?php }else{ ?>
                                                <div class="blog-btn-part2">
                                                    <?php  
                                                        $icon_position = $settings['blog_btn_icon_position'] == 'before' ? 'icon-before' : 'icon-after';
                                                    ?>
                                                        <a class="blog-btn2 <?php echo esc_attr($icon_position) ?>" href="<?php the_permalink(); ?>">
                                                            <?php if(!empty($settings['blog_btn_icon'])) : ?>
                                                                <i class="<?php echo esc_html($settings['blog_btn_icon']);?>"></i>
                                                            <?php else: ?>
                                                                <span class="custom-blog-btn">
                                                                    <i class="glyph-icon flaticon-right-arrow"></i>
                                                                </span>
                                                            <?php endif; ?>
                                                        </a>

                                                </div>
                                          <?php  }
                                        } ?>  

                                        <?php if(!empty($full_date)){ ?>
                                            <div class="blog-meta">
                                                <span class="date"></i>
                                                <?php echo esc_html($full_date);?></span>
                                            </div>
                                        <?php } ?>
                                        <h3 class="blog-name"><a class="pointer-events" href="<?php the_permalink();?>"><?php the_title();?></a></h3>

                                        <?php if(($settings['blog_content_show_hide'] == 'yes') ){ ?>
                                            <p><?php echo wp_trim_words( get_the_content(), $limit, '...' ); ?></p>
                                        <?php } ?>

                                        
                                        <div class="blog-footer d-flex align-items-center justify-content-center">
                                            <?php if(($settings['blog_avatar_show_hide'] == 'yes') ){ ?>
                                                <div class="author-avatar  d-flex align-items-center">
                                                    <?php echo get_avatar(get_the_author_meta( 'ID' ), 40);?> 
                                                    <?php if(!empty($post_admin)){ ?>
                                                        <span class="admin"><?php echo esc_html($post_admin);?></span>
                                                    <?php } ?>
                                                </div>
                                            <?php } ?> 
                                                    
                                            <?php if(($settings['blog_cat_show_hide'] == 'yes') ){ ?>
                                                <div class="cat_list">
                                                    <?php the_category( ); ?>
                                                </div>
                                            <?php } ?>
                                                
                                        </div> 
                                    </div>

                                <?php } elseif (($settings['blog_content_postion_style'] == 'blog_style_3')) { ?>
                                    <div class="blog-content">
                                        <?php if(($settings['blog_readmore_show_hide'] == 'yes') ){ ?>
                                            <?php if(!empty($settings['blog_btn_text'])){ ?>
                                                <div class="blog-btn-part">
                                                    <?php  
                                                        $icon_position = $settings['blog_btn_icon_position'] == 'before' ? 'icon-before' : 'icon-after';
                                                    ?>
                                                        <a class="blog-btn <?php echo esc_attr($icon_position) ?>" href="<?php the_permalink(); ?>">
                                                            <span class="btn-txt"><?php echo esc_html($settings['blog_btn_text']);?></span>
                                                            <?php if(!empty($settings['blog_btn_icon'])) : ?>
                                                                <i class="<?php echo esc_html($settings['blog_btn_icon']);?>"></i>
                                                            <?php endif; ?>
                                                        </a>

                                                </div>
                                            <?php }else{ ?>
                                                <div class="blog-btn-part2">
                                                    <?php  
                                                        $icon_position = $settings['blog_btn_icon_position'] == 'before' ? 'icon-before' : 'icon-after';
                                                    ?>
                                                        <a class="blog-btn2 <?php echo esc_attr($icon_position) ?>" href="<?php the_permalink(); ?>">
                                                          
                                                            <?php if(!empty($settings['blog_btn_icon'])) : ?>
                                                                <i class="<?php echo esc_html($settings['blog_btn_icon']);?>"></i>
                                                            <?php else: ?>
                                                                <span class="custom-blog-btn">
                                                                    <i class="glyph-icon flaticon-right-arrow"></i>
                                                                </span>
                                                            <?php endif; ?>
                                                        </a>

                                                </div>
                                          <?php  }
                                        } ?>  

                                        <?php if(!empty($full_date)){ ?>
                                            <div class="blog-meta">
                                                <span class="date"></i>
                                                <?php echo esc_html($full_date);?></span>
                                            </div>
                                        <?php } ?>
                                        <h3 class="blog-name"><a class="pointer-events" href="<?php the_permalink();?>"><?php the_title();?></a></h3>

                                        <?php if(($settings['blog_content_show_hide'] == 'yes') ){ ?>
                                            <p><?php echo wp_trim_words( get_the_content(), $limit, '...' ); ?></p>
                                        <?php } ?>
                                        
                                        <div class="blog-footer d-flex align-items-center justify-content-center">
                                            <?php if(($settings['blog_avatar_show_hide'] == 'yes') ){ ?>
                                                <div class="author-avatar  d-flex align-items-center">
                                                    <?php echo get_avatar(get_the_author_meta( 'ID' ), 40);?> 
                                                    <?php if(!empty($post_admin)){ ?>
                                                        <span class="admin"><?php echo esc_html($post_admin);?></span>
                                                    <?php } ?>
                                                </div>
                                            <?php } ?> 
                                                    
                                            <?php if(($settings['blog_cat_show_hide'] == 'yes') ){ ?>
                                                <?php if( "bottom" == $settings['blog_cat_postion_style'] ){ ?>
                                                    <div class="cat_list">
                                                        <?php the_category( ); ?>
                                                    </div>
                                                <?php } ?>
                                            <?php } ?>
                                                
                                        </div> 
                                    </div>

                                <?php } elseif (($settings['blog_content_postion_style'] == 'blog_style_4')) { ?>
                                   <div class="blog-content btm-rs blog-style4">

                                    <?php if(($settings['meta_postion_style'] == 'top') ){ ?>

                                        <div class="blog-footer d-flex align-items-center justify-content-between">
                                              
                                            <?php if(!empty($blog_date) || !empty($post_admin)){ ?>
                                                <ul class="blog-meta sep-<?php echo esc_html($settings['blog_separator_show_hide']);?>">

                                                    <?php if(($settings['blog_meta_show_hide'] == 'yes') ){ ?>
                                                    <li class="date">
                                                        <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                        <i class="fa fa-calendar-check-o" aria-hidden="true"></i>
                                                        <?php } ?>
                                                    <?php echo esc_html($blog_date);?></li>
                                                    <?php } ?>

                                                    <?php if(($settings['blog_avatar_show_hide'] == 'yes') ){ ?>
                                                        <?php if(!empty($post_admin)){ ?>
                                                            <li class="admin">
                                                                <?php  if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                                <!-- <i class="fi fi-rr-user"></i>  -->
                                                                <?php
                                                                    $user = wp_get_current_user();

                                                                    print_r($user);

                                                                    if ( $user ) :
                                                                        ?>
                                                                        <img src="<?php echo esc_url( get_avatar_url( $user->ID ) ); ?>" alt=""/>
                                                                    <?php  endif; ?>
                                                                <?php } ?>
                                                                <?php echo esc_html($post_admin);?></li>
                                                        <?php } ?>
                                                    <?php  } ?> 
                                                    
                                                    <?php if(($settings['blog_cat_show_hide'] == 'yes') ){ ?>
                                                        <?php if( "top" != $settings['blog_cat_postion_style'] ){ ?>
                                                            <li class="cat_list btm"> 
                                                                <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                                    <i class="fi fi-rr-bookmark"></i> 
                                                                <?php } ?>
                                                            <?php the_category( ); ?>
                                                            </li>
                                                        <?php } ?>
                                                    <?php } ?>
                                                </ul>
                                            <?php } ?>    
                                        </div>
                                    <?php } ?>
                                        
                                        <h3 class="blog-name"><a class="pointer-events" href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                                        <?php if(($settings['blog_content_show_hide'] == 'yes') ){ ?>
                                            <p><?php echo wp_trim_words( get_the_content(), $limit, '...' ); ?></p>
                                        <?php } ?>

                                        <?php if(($settings['meta_postion_style'] == 'bottom') ){ ?>

                                        <div class="blog-footer d-flex align-items-center justify-content-between">                                                                                                                                                     
                                            <?php if(!empty($blog_date) || !empty($post_admin)){ ?>
                                                <ul class="blog-meta sep-<?php echo esc_html($settings['blog_separator_show_hide']);?>">

                                                    <?php if(($settings['blog_meta_show_hide'] == 'yes') ){ ?>
                                                    <li class="date">
                                                        <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                        <i class="fa fa-calendar-check-o" aria-hidden="true"></i>
                                                        <?php } ?>
                                                    <?php echo esc_html($blog_date);?></li>
                                                    <?php } ?>

                                                    <?php if(($settings['blog_avatar_show_hide'] == 'yes') ){ ?>
                                                        <?php if(!empty($post_admin)){ ?>
                                                            <li class="admin">
                                                                <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                                <i class="fi fi-rr-user"></i> 
                                                                <?php } ?>
                                                                <?php echo esc_html($post_admin);?></li>
                                                        <?php } ?>
                                                    <?php } ?> 
                                                    
                                                    <?php if(($settings['blog_cat_show_hide'] == 'yes') ){ ?>
                                                        <?php if( "top" != $settings['blog_cat_postion_style'] ){ ?>
                                                            <li class="cat_list btm"> 
                                                                <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                                    <i class="fi fi-rr-bookmark"></i> 
                                                                <?php } ?>
                                                            <?php the_category( ); ?>
                                                            </li>
                                                        <?php } ?>
                                                    <?php } ?>
                                                </ul>
                                            <?php } ?>    
                                        </div>
                                    <?php } ?>
                                        
                                        
                                        <?php if(($settings['blog_readmore_show_hide'] == 'yes') ){ ?>
                                            <?php if(!empty($settings['blog_btn_text'])){ ?>
                                                <div class="blog-btn-part <?php echo esc_html($settings['blog_btn_border']);?>">
                                                    <?php  
                                                        $icon_position = $settings['blog_btn_icon_position'] == 'before' ? 'icon-before' : 'icon-after';
                                                    ?>
                                                        <a class="blog-btn <?php echo esc_attr($icon_position) ?>" href="<?php the_permalink(); ?>">
                                                            <span class="btn-txt"><?php echo esc_html($settings['blog_btn_text']);?></span>
                                                            <?php if(!empty($settings['blog_btn_icon'])) : ?>
                                                                <i class="<?php echo esc_html($settings['blog_btn_icon']);?>"></i>
                                                            <?php endif; ?>
                                                        </a>
                                                </div>
                                            <?php }else{ ?>
                                                <div class="blog-btn-part2">
                                                    <?php  
                                                        $icon_position = $settings['blog_btn_icon_position'] == 'before' ? 'icon-before' : 'icon-after';
                                                    ?>
                                                    <a class="blog-btn2 <?php echo esc_attr($icon_position) ?>" href="<?php the_permalink(); ?>">
                                                        <?php if(!empty($settings['blog_btn_icon'])) : ?>
                                                            <i class="<?php echo esc_html($settings['blog_btn_icon']);?>"></i>
                                                        <?php else: ?>
                                                            <span class="custom-blog-btn">
                                                                <i class="glyph-icon flaticon-right-arrow"></i>
                                                            </span>
                                                        <?php endif; ?>
                                                    </a>
                                                </div>
                                          <?php  }
                                        } ?> 
                                    </div> 
                                    <?php } elseif (($settings['blog_content_postion_style'] == 'blog_style_5')) { ?>

                                       


                                   <div class="blog-content btm-rs blog-style4 blog-style5">

                                    <?php if(($settings['meta_postion_style'] == 'top') ){ ?>

                                        <div class="blog-footer d-flex align-items-center justify-content-between">  
                                                                                                                                                                               
                                            <?php if(!empty($blog_date) || !empty($post_admin)){ ?>
                                                <ul class="blog-meta sep-<?php echo esc_html($settings['blog_separator_show_hide']);?>">

                                                    <?php if(($settings['blog_meta_show_hide'] == 'yes') ){ ?>
                                                    <li class="date">
                                                        <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                        <i class="fa fa-calendar-check-o" aria-hidden="true"></i>
                                                        <?php } ?>
                                                    <?php echo esc_html($blog_date);?></li>
                                                    <?php } ?>

                                                    <?php if(($settings['blog_avatar_show_hide'] == 'yes') ){ ?>
                                                        <?php if(!empty($post_admin)){ ?>
                                                            <li class="admin">
                                                                <?php if(($settings['blog_avatar_icon_show'] !== 'yes') ){ ?>
                                                                    <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                                        <i class="fi fi-rr-user"></i> 
                                                                    <?php } ?>
                                                                    <?php
                                                                    if ( $user ) :
                                                                        ?>
                                                                        <img class="admin-image" src="<?php echo esc_url( get_avatar_url( $user->ID ) ); ?>" alt="" />
                                                                    <?php  endif; ?>              
                                                                    <span class="admin-name"><?php echo esc_html($post_admin);?><span>
                                                                <?php } ?>
                                                                <?php if(($settings['blog_avatar_icon_show'] == 'yes') ){ ?>
                                                                    <i class="<?php echo esc_html( $settings['avatar_selected_icon'] );?>"></i> 
                                                                    <span class="admin-name"><?php echo esc_html($post_admin);?><span>
                                                                <?php } ?>
                                                            </li>
                                                        <?php } ?>
                                                    <?php } ?> 
                                                    
                                                    <?php if(($settings['blog_cat_show_hide'] == 'yes') ){ ?>
                                                        <?php if( "top" != $settings['blog_cat_postion_style'] ){ ?>
                                                            <li class="cat_list btm"> 
                                                                <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                                    <i class="<?php echo esc_html( $settings['cat_selected_icon'] );?>"></i> 
                                                                <?php } ?>
                                                            <?php the_category( ); ?>
                                                            </li>
                                                        <?php } ?>
                                                    <?php } ?>
                                                </ul>
                                            <?php } ?>    
                                        </div>
                                    <?php } ?>
                                        
                                        <h3 class="blog-name"><a class="pointer-events" href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                                        <?php if(($settings['blog_content_show_hide'] == 'yes') ){ ?>
                                            <p><?php echo wp_trim_words( get_the_content(), $limit, '...' ); ?></p>
                                        <?php } ?>

                                        <?php if(($settings['meta_postion_style'] == 'bottom') ){ ?>

                                        <div class="blog-footer d-flex align-items-center justify-content-between">                                                                                                                                                          
                                            <?php if(!empty($blog_date) || !empty($post_admin)){ ?>
                                                <ul class="blog-meta sep-<?php echo esc_html($settings['blog_separator_show_hide']);?>">

                                                    <?php if(($settings['blog_avatar_show_hide'] == 'yes') ){ ?>
                                                        <?php if(!empty($post_admin)){ ?>
                                                            <li class="admin">
                                                                <?php if(($settings['blog_avatar_icon_show'] !== 'yes') ){ ?>
                                                                    <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                                        <!-- <i class="fi fi-rr-user"></i>  -->
                                                                    <?php } ?>
                                                                    <?php
                                                                    if ( $user ) :
                                                                        ?>
                                                                        <img class="admin-image" src="<?php echo esc_url( get_avatar_url( $user->ID ) ); ?>" alt="" />
                                                                    <?php  endif; ?>              
                                                                    <span class="admin-name"><?php echo esc_html($post_admin);?><span>
                                                                <?php } ?>
                                                                <?php if(($settings['blog_avatar_icon_show'] == 'yes') ){ ?>
                                                                    <i class="<?php echo esc_html( $settings['avatar_selected_icon'] );?>"></i> 
                                                                    <span class="admin-name"><?php echo esc_html($post_admin);?><span>
                                                                <?php } ?>
                                                            </li>
                                                        <?php } ?>
                                                    <?php } ?> 
                                                    <?php if(($settings['blog_meta_show_hide'] == 'yes') ){ ?>
                                                    <li class="date">
                                                        <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                        <i class="fa fa-calendar-check-o" aria-hidden="true"></i>
                                                        <?php } ?>
                                                    <?php echo esc_html($blog_date);?></li>
                                                    <?php } ?>
                                                    
                                                    <?php if(($settings['blog_cat_show_hide'] == 'yes') ){ ?>
                                                        <?php if( "top" != $settings['blog_cat_postion_style'] ){ ?>
                                                            <li class="cat_list btm"> 
                                                                <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                                    <i class="fi fi-rr-bookmark"></i> 
                                                                <?php } ?>
                                                            <?php the_category( ); ?>
                                                            </li>
                                                        <?php } ?>
                                                    <?php } ?>
                                                </ul>
                                            <?php } ?>    
                                        </div>
                                    <?php } ?>
                                        
                                        
                                        <?php if(($settings['blog_readmore_show_hide'] == 'yes') ){ ?>
                                            <?php if(!empty($settings['blog_btn_text'])){ ?>
                                                <div class="blog-btn-part <?php echo esc_html($settings['blog_btn_border']);?>">
                                                    <?php  
                                                        $icon_position = $settings['blog_btn_icon_position'] == 'before' ? 'icon-before' : 'icon-after';
                                                    ?>
                                                        <a class="blog-btn <?php echo esc_attr($icon_position) ?>" href="<?php the_permalink(); ?>">
                                                            <span class="btn-txt"><?php echo esc_html($settings['blog_btn_text']);?></span>
                                                            <?php if(!empty($settings['blog_btn_icon'])) : ?>
                                                                <i class="<?php echo esc_html($settings['blog_btn_icon']);?>"></i>
                                                            <?php endif; ?>
                                                        </a>
                                                </div>
                                            <?php }else{ ?>
                                                <div class="blog-btn-part2">
                                                    <?php  
                                                        $icon_position = $settings['blog_btn_icon_position'] == 'before' ? 'icon-before' : 'icon-after';
                                                    ?>
                                                    <a class="blog-btn2 <?php echo esc_attr($icon_position) ?>" href="<?php the_permalink(); ?>">
                                                        <?php if(!empty($settings['blog_btn_icon'])) : ?>
                                                            <i class="<?php echo esc_html($settings['blog_btn_icon']);?>"></i>
                                                        <?php else: ?>
                                                            <span class="custom-blog-btn">
                                                                <i class="glyph-icon flaticon-right-arrow"></i>
                                                            </span>
                                                        <?php endif; ?>
                                                    </a>
                                                </div>
                                          <?php  }
                                        } ?> 
                                    </div> 
                                <?php }else{ ?>
                                    <div class="blog-content btm-rs">
                                        <div class="blog-footer d-flex align-items-center justify-content-between">
                                            <?php if(!empty($blog_date) || !empty($post_admin)){ ?>
                                                <ul class="blog-meta sep-<?php echo esc_html($settings['blog_separator_show_hide']);?>">
                                                    <?php if(($settings['blog_avatar_show_hide'] == 'yes') ){ ?>
                                                        <?php if(!empty($post_admin)){ ?>
                                                            <li class="admin">
                                                                <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                                <i class="fi fi-rr-user"></i> 
                                                                <?php } ?>
                                                                <?php echo esc_html($post_admin);?></li>
                                                        <?php } ?>
                                                    <?php } ?> 
                                                    <?php if(($settings['blog_meta_show_hide'] == 'yes') ){ ?>
                                                    <li class="date">
                                                       <?php if(($settings['blog_content_postion_style'] == 'transparent')){ ?>
                                                            <span class="blog_day"><?php echo esc_html($blog_date);?></span>                      
                                                        <?php } ?>
                                                    </li>
                                                    <?php } ?>
                                                    
                                                    <?php if(($settings['blog_cat_show_hide'] == 'yes') ){ ?>
                                                        <?php if( "top" != $settings['blog_cat_postion_style'] ){ ?>
                                                            <li class="cat_list btm"> 
                                                                <?php if(($settings['blog_meta_icon_hide'] == 'yes') ){ ?>
                                                                    <i class="fi fi-rr-bookmark"></i> 
                                                                <?php } ?>
                                                            <?php the_category( ); ?>
                                                            </li>
                                                        <?php } ?>

                                                    <?php } ?>
                                                </ul>
                                            <?php } ?>    
                                        </div>
                                        <h3 class="blog-name"><a class="pointer-events" href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                                        <?php if(($settings['blog_content_show_hide'] == 'yes') ){ ?>
                                            <p><?php echo wp_trim_words( get_the_content(), $limit, '...' ); ?></p>
                                        <?php } ?>
                                        <?php if(($settings['blog_readmore_show_hide'] == 'yes') ){ ?>
                                            <?php if(!empty($settings['blog_btn_text'])){ ?>
                                                <div class="blog-btn-part <?php echo esc_html($settings['blog_btn_border']);?>">
                                                    <?php  
                                                        $icon_position = $settings['blog_btn_icon_position'] == 'before' ? 'icon-before' : 'icon-after';
                                                    ?>
                                                        <a class="blog-btn <?php echo esc_attr($icon_position) ?>" href="<?php the_permalink(); ?>">
                                                            <span class="btn-txt"><?php echo esc_html($settings['blog_btn_text']);?></span>
                                                            <?php if(!empty($settings['blog_btn_icon'])) : ?>
                                                                <i class="<?php echo esc_html($settings['blog_btn_icon']);?>"></i>
                                                            <?php endif; ?>
                                                        </a>
                                                </div>
                                            <?php }else{ ?>
                                                <div class="blog-btn-part2">
                                                    <?php  
                                                        $icon_position = $settings['blog_btn_icon_position'] == 'before' ? 'icon-before' : 'icon-after';
                                                    ?>
                                                    <a class="blog-btn2 <?php echo esc_attr($icon_position) ?>" href="<?php the_permalink(); ?>">
                                                        <?php if(!empty($settings['blog_btn_icon'])) : ?>
                                                            <i class="<?php echo esc_html($settings['blog_btn_icon']);?>"></i>
                                                        <?php else: ?>
                                                            <span class="custom-blog-btn">
                                                                <?php esc_html_e('Read More', 'tekhub');?> <i class="glyph-icon flaticon-right-arrow"></i>
                                                            </span>
                                                        <?php endif; ?>
                                                    </a>
                                                </div>
                                          <?php  }
                                        } ?> 
                                    </div>   
                                <?php } ?>
                            </div>
                        </div>
                    <?php
                    endwhile;
                    wp_reset_query();  ?>
                </div>
                <div class="rsaddon-slider-conf wpsisac-hide" data-conf="<?php echo htmlspecialchars(json_encode($slider_conf)); ?>"></div>
            </div>
            <script type="text/javascript"> 
            jQuery(document).ready(function(){
            jQuery( '.rs-addon-slider' ).each(function( index ) {        
            var slider_id       = jQuery(this).attr('id'); 
            var slider_conf     = jQuery.parseJSON( jQuery(this).closest('.rsaddon-unique-slider').find('.rsaddon-slider-conf').attr('data-conf'));
           
            if( typeof(slider_id) != 'undefined' && slider_id != '' ) {
            jQuery('#'+slider_id).not('.slick-initialized').slick({
            slidesToShow    : parseInt(slider_conf.col_lg),
            centerMode      : (slider_conf.centerMode)  == "true" ? true : false,
            dots            : (slider_conf.sliderDots)  == "true" ? true : false,
            arrows          : (slider_conf.sliderNav) == "true" ? true : false,
            autoplay        : (slider_conf.slider_autoplay) == "true" ? true : false,
            slidesToScroll  : parseInt(slider_conf.slidesToScroll),
            centerPadding   : '15px',
            autoplaySpeed   : parseInt(slider_conf.autoplaySpeed),
            pauseOnHover    : (slider_conf.pauseOnHover) == "true" ? true : false,
            loop : false,
            rtl: <?php echo $rtl; ?>,
            responsive: [{
                breakpoint: 1200,
                settings: {
                    slidesToShow: parseInt(slider_conf.col_md),
                }
            }, 
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: parseInt(slider_conf.col_sm),
                }
            }, 
            {
                breakpoint: 768,
                settings: {
                    arrows: false,
                    slidesToShow: parseInt(slider_conf.col_xs),
                }
            }, ]
            });
        }
       
        });
    });
    </script>
        <?php

    }
}?>